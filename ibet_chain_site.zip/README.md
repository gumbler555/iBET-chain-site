# iBET Chain Website
Simple GitHub Pages website for the iBET L1 blockchain project.